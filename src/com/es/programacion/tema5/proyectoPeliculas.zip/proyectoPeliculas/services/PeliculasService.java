package com.Programacion.Tema5.proyectoPeliculas.services;

import java.util.Collections;
import java.util.Comparator;

import com.Programacion.Tema5.proyectoPeliculas.MainCreacion;
import com.Programacion.Tema5.proyectoPeliculas.clases.Pelicula;


import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.UUID;

import static com.Programacion.Tema5.proyectoPeliculas.MainCreacion.peliculas;

public class PeliculasService {


    public static boolean addPelicula() {
        // Adicion de una pelicula nueva
        Scanner scan = new Scanner(System.in);

        System.out.print("Dime el nombre de la pelicula: ");
        String nombrePeli = scan.nextLine();

        int anio = 0;
        try {
            System.out.print("Dime el anio de publicación de la pelicula: ");
            anio = scan.nextInt();
            scan.nextLine();
        } catch (InputMismatchException e) {
            System.out.println("Anio erroneo...");
        }

        System.out.print("Dime el nombre del director/a: ");
        String dir = scan.nextLine();


        System.out.print("Dime el nombre del/a actor/actriz 1: ");
        String act1 = scan.nextLine();


        System.out.print("Dime el nombre del/a actor/actriz 2: ");
        String act2 = scan.nextLine();

        String id = UUID.randomUUID().toString();

        double nota = 0.0;
        try {
            System.out.print("Dime la nota de la pelicula: ");
            nota = scan.nextDouble();
            scan.nextLine();
        } catch (InputMismatchException e) {
            System.out.println("Nota erronea...");
        }

        Pelicula peliNueva = new Pelicula(id, nombrePeli, anio+"",
                dir, act1, act2, nota+"");



        boolean peliExiste = false;
        for(int i = 0; i< peliculas.size(); i++) {

            if(peliculas.get(i).getId().equals(peliNueva.getId())) {
                System.out.println("Pelicula ya existente");
                peliExiste = true;
                break;
            }

        }

        if(!peliExiste){

            // Vamos a comprobar la posición en la que tenemos que meter la peli
            for (int i = 0; i< peliculas.size(); i++){
                double notaPelinueva = Double.parseDouble(peliNueva.getImDbRating());
                double notaPeliLista = Double.parseDouble(peliculas.get(i).getImDbRating());

                if (notaPelinueva > notaPeliLista){
                    //Insertamos la peliNueva en la posición de la pelicula de la lista
                    peliNueva.setRank(peliculas.get(i).getRank());
                    peliculas.add(i, peliNueva);

                    // For para actualizar el Rank de las películas y J es el valor de i + 1
                    for (int j = i+1; j< peliculas.size(); j++){

                        int rankingAntiguo = Integer.parseInt(peliculas.get(j).getRank());
                        int rankingNuevo = rankingAntiguo + 1;
                        peliculas.get(j).setRank(rankingNuevo+"");
                    }

                    break;
                }
            }

            System.out.println("Pelicula correctamente añadida...");
            return true;
        }



        return false;
    }
    public static void mostrarPeliculasDesc(){
        for (int j = 0; j< peliculas.size(); j++){
            System.out.printf("|-----------(%s)---------------\n", peliculas.get(j).getRank());
            System.out.printf("|- Titulo (año): %s\n", peliculas.get(j).getFullTitle());
            System.out.printf("|\t- Nota: %s\n", peliculas.get(j).getImDbRating());
            System.out.printf("|\t- Reparto: %s\n", peliculas.get(j).getCrew());
        }
    }

    public static void mostrarPeliculasAsc() {
        // Ordenar la lista de películas por nota de mayor a menor
        peliculas.sort(Comparator.comparingDouble(p -> -Double.parseDouble(p.getImDbRating())));

        // Mostrar la lista ordenada
        System.out.println("Lista de películas de menor a mayor nota:");
        for (Pelicula pelicula : peliculas) {
            System.out.printf("|-----------(%s)---------------\n", pelicula.getRank());
            System.out.printf("|- Titulo (año): %s\n", pelicula.getFullTitle());
            System.out.printf("|\t- Nota: %s\n", pelicula.getImDbRating());
            System.out.printf("|\t- Reparto: %s\n", pelicula.getCrew());
        }
    }

    public static void mostrarPeliculasDesde2000() {
        // Obtener el año actual (2024)
        int currentYear = 2024;

        // Mostrar las películas del año 2000 hasta la actualidad (2024) ordenadas por nota de mayor a menor
        System.out.println("Lista de películas del año 2000 hasta 2024, ordenadas por nota de mayor a menor:");
        for (Pelicula pelicula : peliculas) {
            int year = Integer.parseInt(pelicula.getYear());

            if (year >= 2000 && year <= currentYear) {
                System.out.printf("|-----------(%s)---------------\n", pelicula.getRank());
                System.out.printf("|- Título (año): %s\n", pelicula.getFullTitle());
                System.out.printf("|\t- Nota: %s\n", pelicula.getImDbRating());
                System.out.printf("|\t- Reparto: %s\n", pelicula.getCrew());
            }
        }
    }

    public static void mostrarPeliculasConNota() {
        // Obtener el año actual (2024)
        int currentYear = 2024;

        Scanner scanner = new Scanner(System.in);

        // Pedir al usuario que ingrese la nota mínima de la película
        System.out.print("Ingrese la nota mínima de la película: ");
        int notaMinima = scanner.nextInt();

        System.out.println("Lista de películas del año 2000 hasta 2024, con nota igual o superior a " + notaMinima);
        for (Pelicula pelicula : peliculas) {
            int year = Integer.parseInt(pelicula.getYear());
            double nota = Double.parseDouble(pelicula.getImDbRating());

            if (year >= 2000 && year <= currentYear && nota >= notaMinima) {
                System.out.printf("|-----------(%s)---------------\n", pelicula.getRank());
                System.out.printf("|- Título (año): %s\n", pelicula.getFullTitle());
                System.out.printf("|\t- Nota: %s\n", pelicula.getImDbRating());
                System.out.printf("|\t- Reparto: %s\n", pelicula.getCrew());
            }
        }
    }

    public static void mostrarPeliculaPorTitulo() {
        Scanner scanner = new Scanner(System.in);

        // Pedir al usuario que ingrese el título de la película
        System.out.print("Ingrese el título completo de la película (incluyendo el año): ");
        String tituloBuscado = scanner.nextLine();

        // Buscar la película por título
        Pelicula peliculaEncontrada = null;
        for (Pelicula pelicula : peliculas) {
            if (pelicula.getFullTitle().equalsIgnoreCase(tituloBuscado)) {
                peliculaEncontrada = pelicula;
                break; // Terminar el bucle si se encuentra la película
            }
        }

        // Mostrar la información de la película encontrada o mensaje de no encontrada
        if (peliculaEncontrada != null) {
            System.out.println("Información de la película encontrada:");
            System.out.printf("|-----------(%s)---------------\n", peliculaEncontrada.getRank());
            System.out.printf("|- Título (año): %s\n", peliculaEncontrada.getFullTitle());
            System.out.printf("|\t- Nota: %s\n", peliculaEncontrada.getImDbRating());
            System.out.printf("|\t- Reparto: %s\n", peliculaEncontrada.getCrew());
        } else {
            System.out.println("No se encontró ninguna película con el título proporcionado.");
        }
    }

    public static void mostrarPeliculaPorDirector() {
        Scanner scanner = new Scanner(System.in);

        // Pedir al usuario que ingrese el nombre del director
        System.out.print("Ingrese el nombre del director: ");
        String directorBuscado = scanner.nextLine();

        // Buscar la película por director
        Pelicula peliculaEncontrada = null;
        for (Pelicula pelicula : peliculas) {
            if (pelicula.getCrew().toLowerCase().contains(directorBuscado.toLowerCase())) {
                peliculaEncontrada = pelicula;
                break; // Terminar el bucle si se encuentra la película
            }
        }

        // Mostrar la información de la película encontrada o mensaje de no encontrada
        if (peliculaEncontrada != null) {
            System.out.println("Información de la película encontrada:");
            System.out.printf("|-----------(%s)---------------\n", peliculaEncontrada.getRank());
            System.out.printf("|- Título (año): %s\n", peliculaEncontrada.getFullTitle());
            System.out.printf("|\t- Nota: %s\n", peliculaEncontrada.getImDbRating());
            System.out.printf("|\t- Reparto: %s\n", peliculaEncontrada.getCrew());
        } else {
            System.out.println("No se encontró ninguna película con el director proporcionado.");
        }
    }

    public static void eliminarPelicula() {
        Scanner scanner = new Scanner(System.in);

        // Mostrar la lista actual de películas
        System.out.println("Lista actual de películas:");
        mostrarPeliculasDesc();

        // Solicitar al usuario el Rank de la película a eliminar
        System.out.print("Ingrese el Rank de la película que desea eliminar: ");
        String rankToDelete = scanner.nextLine();

        // Buscar la película en la lista por el Rank
        boolean peliculaEncontrada = false;
        for (int i = 0; i < peliculas.size(); i++) {
            if (peliculas.get(i).getRank().equals(rankToDelete)) {
                peliculas.remove(i);
                peliculaEncontrada = true;
                break;
            }
        }

        // Mostrar el resultado
        if (peliculaEncontrada) {
            System.out.println("La película con Rank " + rankToDelete + " se ha eliminado correctamente.");
            System.out.println("Lista actualizada de películas:");
            mostrarPeliculasDesc();
        } else {
            System.out.println("No se encontró ninguna película con el Rank proporcionado.");
        }
    }



}
